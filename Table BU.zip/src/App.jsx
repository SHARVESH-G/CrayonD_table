import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { Tooltip } from '@mui/material'
import Table from './Components/Table'

function App() {

  return (
    <Table/>
  );
}

export default App
