export default function DisplayTable()
{
    
}