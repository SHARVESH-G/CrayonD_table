import { TablePagination } from "@mui/material";

export default function PG()
{
    return(
        <TablePagination
                rowsPerPageOptions={[4, 8, 12]}
                component="div"
                count={members.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
            />
    );
}